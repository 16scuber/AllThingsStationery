const { application } = require('express');
const express = require('express');
const controller = require('../controllers/mainController');
const {isGuest, isLoggedIn} = require('../middlewares/auth');

const router = express.Router();

router.get('/contact', isGuest, controller.contact);

router.get('/about', isGuest, controller.about);

router.get('/newUser', isGuest, controller.newUser);

//router.get('/logout', isLoggedIn, controller.logout);
router.get('/profile', isLoggedIn, controller.profile);

module.exports = router;