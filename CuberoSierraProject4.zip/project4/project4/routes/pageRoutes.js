const { application } = require('express');
const express = require('express');
const controller = require('../controllers/pageController');
const {isGuest, isLoggedIn, isAuthor} = require('../middlewares/auth');

const router = express.Router();

//GET /stories/new: send html form for creating a new trade

router.get('/new', isLoggedIn, controller.new);

router.get('/', controller.trades);

router.post('/', isLoggedIn, controller.create);

router.get('/:id', isLoggedIn, controller.show);

router.get('/:id/edit', isLoggedIn, isAuthor, controller.edit);

router.post('/:id', isLoggedIn, isAuthor, controller.update);

router.delete('/:id', isLoggedIn, isAuthor, controller.delete);

//router.get('/logout', isLoggedIn, controller.logout);

module.exports = router;