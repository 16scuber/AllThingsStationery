const Trade = require('../models/page');

exports.isGuest = (req, res, next) => {
    if(!req.session.user){
        return next();
    }else {
        req.flash('error', 'You are logged in already');
        return res.redirect('/profile');
    }
}

exports.isLoggedIn = (req, res, next) => {
    if(req.session.user) {
        return next();
    } else {
        req.flash('error', 'You need to login first');
        return res.redirect('/login');
    }
}

exports.isAuthor = (req, res, next) => {
    let id = req.params.id;
    Trade.findById(id)
    .then(trade => {
        if(trade) {
            if(trade.author == req.session.user) {
                return next();
            } else {
                let err = new Error('Unauthorized access to resource');
                err.status = 401;
                return next(err);
            }
        }
    })
    .catch(err=>next(err));
};