//require modules
const express = require('express');
const morgan = require('morgan');
const methodOverride = require('method-override');
const pageRoutes = require('./routes/pageRoutes');
const mainRoutes = require('./routes/mainRoutes');
const {MongoClient} = require('mongodb');
const mongoose = require('mongoose');
const {getCollection} = require('./models/page');
const session = require('express-session');
const User = require('./models/user');
const flash = require('connect-flash');
const MongoStore = require('connect-mongo');

//create app
const app = express();

//configure app
let port = 3000;
let host = 'localhost';
app.set('view engine', 'ejs');

app.use(flash());

//connect to database
mongoose.connect('mongodb://localhost:27017/local', 
        {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true })
.then(()=> {
    app.listen(port, host, () => {
        console.log('Server is running on port', port);
    });
})
.catch(err => console.log(err.message)); 


//mount middleware
app.use(express.static('public'));
app.use(express.urlencoded({extended: true}));
app.use(morgan('tiny'));
app.use(methodOverride('_method'));

app.use(session({
    secret: 'jiaru90aeur90ef93oioefe',
    resave: false,
    saveUninitialized: true, 
    cookie: {maxAge: 60*60*1000},
    store: new MongoStore({mongoUrl: 'mongodb://localhost:27017/local'})
}));

app.use((req, res, next) => {
    console.log(req.session);
    res.locals.user = req.session.user||null;
    res.locals.successMessages = req.flash('success');
    res.locals.errorMessages = req.flash('error');
    next();
})


//set up routes
app.get('/', (req, res) => {
    res.render('index');
});

app.get('/new', (req, res) => {
    res.render('new');
});

app.get('/newUser', (req, res) => {
    res.render('newUser');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res, next) => {
    let email = req.body.email;
    let password = req.body.password;
    console.log(req.flash());

    User.findOne({email: email})
    .then(user=> {
        if (user) {
            user.comparePassword(password) 
            .then(result => {
                if (result) {
                    req.session.user = user._id;
                    req.flash('success', 'You have successfully logged in');
                    res.redirect('/info/profile');
                } else {
                    req.flash('error', 'Wrong password!');
                    res.redirect('/login');
                }
            })
        } else {
            req.flash('error', 'Wrong email address!');
            res.redirect('/login');
        }
    })
    .catch(err=>next(err));
});



app.get('/logout', (req, res, next) => {
    req.session.destroy(err => {
        if(err) 
        return next(err);
        else
        res.redirect('/');
    }); 
});



app.post('/', (req, res, next) => {
    let user = new User(req.body);
    user.save()
    .then(()=> res.redirect('/login'))
    .catch(err=>{
        if(err.name === 'ValidationError') {
            req.flash('error', err.message);
            return res.redirect('/new');
        }
        if(err.code === 11000) {
        req.flash('error', 'Email address has been used');
        return res.redirect('/new');
        }
    next(err);
    });
});

app.use('/trades', pageRoutes);

app.use('/info', mainRoutes);

app.use((req, res, next) => {
    let err = new Error('The server cannot locate ' + req.url);
    err.status = 404;
    next(err);
});

app.use((err, req, res, next) => {
    console.log(err.stack);
    if(!err.status) {
        err.status = 500;
        err.message = ("Internal Server Error");
    }

    res.status(err.status);
    res.render('error', {error: err});
});
