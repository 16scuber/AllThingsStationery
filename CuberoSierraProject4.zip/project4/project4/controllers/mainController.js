const model = require('../models/user');
const Trade = require('../models/page');

exports.contact = (req, res) => {
    res.render('contact');
};

exports.about = (req, res) => {
    res.render('about');
};

exports.newUser = (req, res) => {
    res.render('newUser');
};

exports.profile = (req, res, next) => {
    let id = req.session.user;
    Promise.all([model.findById(id), Trade.find({author: id})])
    .then(results=> {
        const [user, trades] = results;
        res.render('profile', {user, trades});
    })
    .catch(err=>next(err));
};

