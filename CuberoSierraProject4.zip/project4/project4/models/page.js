const { DateTime } = require('luxon');
const {v4: uuidv4} = require('uuid');
const mongoose = require('mongoose');
const Schema = mongoose.Schema;
//const { trades } = require('../controllers/pageController');

const tradesSchema = new Schema({
    author: {type: Schema.Types.ObjectId, ref: 'User'},
    typeSelection: {type: String, required:[true, 'type is required']},
    brand: {type: String, required:[true, 'brand is required']},
    model: {type: String, required:[true, 'model is required']},
    nibSize: {type: String, required:[false]},
    inkColor: {type: String, required:[true, 'ink color is required']},
    details: {type: String, required:[true, 'details are required']},
    //id: {type: String, required:[false]},
},
{timestamps: true}
);

module.exports = mongoose.model('trades', tradesSchema);


exports.find = () => trades.find().toArray();

exports.findById = id => trades.findOne({_id: ObjectId(id)});

exports.findByCategory = typeSelection => trades.find(trade=>trade.typeSelection === typeSelection);

exports.save = page => trades.insertOne(page);


exports.updateById = function(id, newTrade) {
    let trade = trades.find(trade=>trade.id === id);
    if(trade) {
        trade.typeSelection = newTrade.typeSelection;
        trade.brand = newTrade.brand;
        trade.model = newTrade.model;
        trade.nibSize = newTrade.nibSize;
        trade.inkColor = newTrade.inkColor;
        trade.details = newTrade.details;
        return true;
    } else {
        return false;
    }
}

exports.deleteById = function(id) {
    let index = trades.find(trade => trade.id === id);
    if(index !== -1) {
        trades.splice(index, 1);
        return true;
    } else {
        return false;
    }
}